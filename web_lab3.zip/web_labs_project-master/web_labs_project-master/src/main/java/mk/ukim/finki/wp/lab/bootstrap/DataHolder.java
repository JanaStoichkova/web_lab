package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.jpa.AlbumRepository;
import mk.ukim.finki.wp.lab.repository.jpa.SongRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class DataHolder {

    public static List<Artist> lista_artisti = new ArrayList<>();
    public static List<Song> lista_pesni = new ArrayList<>();
    public static List<Album> lista_albumi = new ArrayList<>();
    public static Long id;
    private final AlbumRepository albumRepository;
    private final SongRepository songRepository;

    public DataHolder(AlbumRepository albumRepository, SongRepository songRepository) {
        this.albumRepository = albumRepository;
        this.songRepository = songRepository;
    }


    @PostConstruct
    public void init() {

        lista_artisti.add(new Artist (1L, "Taylor", "Swift", "bio1"));
        lista_artisti.add(new Artist (2L, "David", "Bowie", "bio2"));
        lista_artisti.add(new Artist (3L, "Sabrina", "Carpenter", "bio3"));
        lista_artisti.add(new Artist (4L, "Elvis", "Presly", "bio4"));
        lista_artisti.add(new Artist (5L, "Zach", "Bryan", "bio5"));

        lista_albumi.add(new Album (1L, "Blondie", "Jazz", "1977"));
        lista_albumi.add(new Album (2L, "Rapture", "Pop", "1997"));
        lista_albumi.add(new Album (3L, "Donda", "Rap", "2020"));
        lista_albumi.add(new Album (4L, "a4", "Jazz", "2018"));
        lista_albumi.add(new Album (5L, "a5", "Rap", "2004"));

        lista_pesni.add(new Song("1", "Blinding Lights", "Pop", 2020, lista_albumi.get(0)));

        lista_pesni.add(new Song("2", "Shape of You", "Pop", 2017, lista_albumi.get(0)));

        lista_pesni.add(new Song("3", "Bohemian Rhapsody", "Rock", 1975, lista_albumi.get(1)));

        lista_pesni.add(new Song("4", "Uptown Funk", "Funk", 2014, lista_albumi.get(1)));

        lista_pesni.add(new Song("5", "Rolling in the Deep", "Soul", 2010, lista_albumi.get(2)));

        if (albumRepository.count() == 0) {
            // Create albums (or you can fetch these from a list)
            Album album1 = new Album(10L, "Taylor", "rap", "2010");
            Album album2 = new Album(20L, "Taylor1", "rap", "2010");
            Album album3 = new Album(30L, "Taylor2", "rap", "2010");
            Album album4 = new Album(40L, "Taylor3", "rap", "2010");
            Album album5 = new Album(50L, "Taylor4", "rap", "2010");

            // Save albums to the database
            albumRepository.saveAll(Arrays.asList(album1, album2, album3, album4, album5));
            //System.out.println("Albums added to the database!");
        }
        if (songRepository.count() == 0) {
            // Create albums (or you can fetch these from a list)
            Song song1 = new Song("1", "Blinding Lights", "Pop", 2020, lista_albumi.get(0));
            Song song2 = new Song("2", "Shape of You", "Pop", 2017, lista_albumi.get(0));


            // Save albums to the database
            songRepository.saveAll(Arrays.asList(song1,song2));
            //System.out.println("Albums added to the database!");
        }

    }

}